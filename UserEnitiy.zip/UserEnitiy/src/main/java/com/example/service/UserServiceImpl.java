package com.example.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.entity.User;
import com.example.repository.UserRepository;

@Service
public class UserServiceImpl {
	
	@Autowired
	private UserRepository repository;

	public User saveUser(User user) {
		return repository.save(user);
	}

	public List<User> getUserList() {
		return repository.findAll();
	}

	public User getUserById(Long id) {
		return repository.findById(id).get();
	}

	public void deleteUserById(Long id) {
		repository.deleteById(id);		
	}

}
