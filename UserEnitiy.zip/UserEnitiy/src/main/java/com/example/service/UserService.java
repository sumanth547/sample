package com.example.service;

public interface UserService {

}
